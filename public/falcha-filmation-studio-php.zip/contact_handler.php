<?php
/**
 * Contact Submission Handler
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = strip_tags(trim($_POST['name'] ?? ''));
    $email = filter_var(trim($_POST['email'] ?? ''), FILTER_SANITIZE_EMAIL);
    $message = strip_tags(trim($_POST['message'] ?? ''));

    // Optional: save to contacts.log or email using mail()
    $logEntry = date('Y-m-d H:i:s') . " | Name: $name | Email: $email | Message: $message\n";
    @file_put_contents(__DIR__ . '/contacts.log', $logEntry, FILE_APPEND);

    // Redirect back with success message
    echo "<!DOCTYPE html><html><head><meta charset='UTF-8'><meta http-equiv='refresh' content='2;url=index.php'><script src='https://cdn.tailwindcss.com'></script></head><body class='bg-[#070a0e] text-white flex items-center justify-center min-h-screen'><div class='text-center p-8 bg-zinc-900 border border-white/20 rounded-2xl'><h2 class='text-xl font-bold mb-2'>Proposal Received</h2><p class='text-sm text-slate-400'>Thank you, $name. We will get in touch shortly.</p><p class='text-xs text-slate-500 mt-4'>Redirecting to home...</p></div></body></html>";
    exit;
}
header('Location: index.php');
exit;

<?php
/**
 * Direct file download script for the Falcha PHP Website Package
 */
$zipFile = __DIR__ . '/falcha-filmation-studio-php.zip';

if (!file_exists($zipFile)) {
    // Look in parent or assets
    $zipFile = dirname(__DIR__) . '/public/falcha-filmation-studio-php.zip';
}

if (file_exists($zipFile)) {
    header('Content-Description: File Transfer');
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="falcha-filmation-studio-php.zip"');
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    header('Content-Length: ' . filesize($zipFile));
    readfile($zipFile);
    exit;
} else {
    http_response_code(404);
    echo "Download package not found.";
}

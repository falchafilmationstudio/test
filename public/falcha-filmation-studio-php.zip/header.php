<!DOCTYPE html>
<html lang="en" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo STUDIO_NAME . ' ' . STUDIO_SUBTITLE; ?> | <?php echo STUDIO_TAGLINE; ?></title>
    <meta name="description" content="Falcha Filmation Studio – Storytelling in Motion. Dedicated to high-caliber documentaries, commercials, and short films.">
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@500;600;700;800;900&family=Montserrat:wght@300;400;500;600;700;800;900&family=Noto+Sans+Devanagari:wght@400;500;600;700&display=swap" rel="stylesheet">
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    fontFamily: {
                        cinzel: ['Cinzel', 'Georgia', 'serif'],
                        montserrat: ['Montserrat', 'sans-serif'],
                        devanagari: ['Noto Sans Devanagari', 'sans-serif'],
                    }
                }
            }
        }
    </script>
    <style>
        .font-devanagari { font-family: 'Noto Sans Devanagari', sans-serif; }
        .font-montserrat { font-family: 'Montserrat', sans-serif; }
        .font-cinzel { font-family: 'Cinzel', serif; }
    </style>
</head>
<body class="bg-[#070a0e] text-slate-100 min-h-screen flex flex-col justify-between overflow-x-hidden antialiased selection:bg-white/20 selection:text-white">

    <!-- Atmospheric Backdrops -->
    <div class="fixed inset-0 pointer-events-none -z-20 opacity-80" style="background: radial-gradient(circle at 50% 22%, rgba(20, 32, 48, 0.45) 0%, rgba(10, 15, 22, 0.9) 60%, #06080b 100%);"></div>
    <div class="fixed inset-0 pointer-events-none -z-10 opacity-60" style="background: radial-gradient(ellipse 60% 45% at 50% 12%, rgba(255, 255, 255, 0.05) 0%, rgba(160, 200, 240, 0.015) 50%, transparent 80%);"></div>

    <!-- Header Navigation -->
    <header class="w-full pt-4 md:pt-6 pb-2 px-4 sm:px-8 md:px-12 flex justify-between items-center z-30 select-none">
        <!-- Brand Logo on Left matching reference image asd.png -->
        <a href="index.php" class="flex items-center space-x-3 sm:space-x-3.5 group transition-transform duration-200 hover:scale-[1.02]">
            <div class="relative w-10 h-10 sm:w-12 sm:h-12 md:w-13 md:h-13 rounded-xl overflow-hidden bg-black/60 border border-white/20 shadow-[0_4px_16px_rgba(0,0,0,0.8)] group-hover:border-amber-400/50 transition-colors">
                <img src="assets/images/logo.jpg" alt="Falcha Filmation Studio Logo" class="w-full h-full object-cover filter contrast-110 brightness-105 group-hover:scale-105 transition-transform duration-300">
            </div>
            <div class="flex flex-col text-left">
                <span class="font-montserrat text-base sm:text-lg md:text-xl font-black tracking-[0.16em] text-white leading-tight uppercase drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)] group-hover:text-amber-100 transition-colors">
                    <?php echo STUDIO_NAME; ?>
                </span>
                <span class="font-montserrat text-[8.5px] sm:text-[9.5px] md:text-[10px] font-bold tracking-[0.22em] text-slate-300 uppercase leading-none mt-0.5">
                    <?php echo STUDIO_SUBTITLE; ?>
                </span>
            </div>
        </a>

        <!-- Navigation Links on Right -->
        <nav class="flex items-center space-x-5 sm:space-x-8 md:space-x-10 text-xs sm:text-[13px] tracking-[0.2em] font-medium font-montserrat">
            <a href="index.php" class="relative py-1 text-white font-semibold uppercase">
                WORK
                <span class="absolute bottom-0 left-0 right-0 h-[2px] bg-white rounded-full shadow-[0_0_8px_rgba(255,255,255,0.7)]"></span>
            </a>
            <button onclick="openModal('servicesModal')" class="relative py-1 text-slate-400 hover:text-slate-200 uppercase transition-colors">
                SERVICES
            </button>
            <button onclick="openModal('aboutModal')" class="relative py-1 text-slate-400 hover:text-slate-200 uppercase transition-colors">
                ABOUT
            </button>
            <button onclick="openModal('contactModal')" class="relative py-1 text-slate-400 hover:text-slate-200 uppercase transition-colors">
                CONTACT
            </button>
        </nav>
    </header>

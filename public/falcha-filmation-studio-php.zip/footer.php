    <!-- Footer -->
    <footer class="w-full py-4 text-center text-[10px] text-slate-500/70 tracking-widest uppercase font-montserrat select-none">
        <?php echo STUDIO_NAME . ' ' . STUDIO_SUBTITLE; ?> • ALL RIGHTS RESERVED • STORYTELLING IN MOTION
    </footer>

    <!-- Video Modal Player -->
    <div id="videoModal" class="fixed inset-0 z-50 hidden items-center justify-center p-3 sm:p-6 md:p-10 bg-black/90 backdrop-blur-md">
        <div class="relative w-full max-w-5xl bg-[#0b0e14] border border-white/20 rounded-2xl overflow-hidden shadow-[0_25px_70px_rgba(0,0,0,0.95)] flex flex-col" onclick="event.stopPropagation()">
            <div class="flex items-center justify-between px-5 py-3.5 bg-black/60 border-b border-white/10 z-20">
                <div class="flex items-center space-x-3">
                    <span class="w-2 h-2 rounded-full bg-red-500 animate-ping"></span>
                    <div>
                        <h2 id="modalVideoTitle" class="text-sm md:text-base font-bold text-white font-montserrat tracking-wider"></h2>
                        <p id="modalVideoNepaliTitle" class="text-xs text-slate-400 font-devanagari"></p>
                    </div>
                </div>
                <button onclick="closeVideoModal()" class="p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-white/10 transition-colors">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                </button>
            </div>
            <div class="relative aspect-video w-full bg-black flex items-center justify-center">
                <video id="mainVideoPlayer" controls playsinline class="w-full h-full object-contain"></video>
            </div>
            <div class="p-5 sm:p-6 bg-[#0e131a] border-t border-white/10">
                <p id="modalVideoSynopsis" class="text-slate-300 text-sm leading-relaxed font-light"></p>
            </div>
        </div>
    </div>

    <!-- Services Modal -->
    <div id="servicesModal" class="fixed inset-0 z-40 hidden items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md">
        <div class="relative w-full max-w-3xl max-h-[90vh] bg-[#0c1017] border border-white/20 rounded-2xl shadow-[0_20px_60px_rgba(0,0,0,0.9)] overflow-y-auto flex flex-col p-6 sm:p-8" onclick="event.stopPropagation()">
            <div class="flex items-center justify-between pb-4 mb-6 border-b border-white/10">
                <div>
                    <h2 class="font-cinzel text-xl sm:text-2xl font-bold tracking-widest text-white uppercase">SERVICES</h2>
                    <p class="text-xs text-slate-400 font-montserrat tracking-widest uppercase mt-1">FALCHA FILMATION STUDIO • KATHMANDU, NEPAL</p>
                </div>
                <button onclick="closeModal('servicesModal')" class="p-2 rounded-full text-slate-400 hover:text-white hover:bg-white/10">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                </button>
            </div>
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <?php foreach ($services as $service): ?>
                <div class="p-5 rounded-xl bg-white/[0.03] border border-white/10 space-y-2">
                    <h3 class="font-montserrat text-sm font-bold text-white"><?php echo htmlspecialchars($service['title']); ?></h3>
                    <p class="font-devanagari text-xs text-slate-400"><?php echo htmlspecialchars($service['nepali']); ?></p>
                    <p class="text-xs text-slate-300 leading-relaxed font-light pt-1"><?php echo htmlspecialchars($service['desc']); ?></p>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <!-- About Modal -->
    <div id="aboutModal" class="fixed inset-0 z-40 hidden items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md">
        <div class="relative w-full max-w-3xl max-h-[90vh] bg-[#0c1017] border border-white/20 rounded-2xl shadow-[0_20px_60px_rgba(0,0,0,0.9)] overflow-y-auto flex flex-col p-6 sm:p-8" onclick="event.stopPropagation()">
            <div class="flex items-center justify-between pb-4 mb-6 border-b border-white/10">
                <div>
                    <h2 class="font-cinzel text-xl sm:text-2xl font-bold tracking-widest text-white uppercase">ABOUT</h2>
                    <p class="text-xs text-slate-400 font-montserrat tracking-widest uppercase mt-1"><?php echo STUDIO_TAGLINE; ?></p>
                </div>
                <button onclick="closeModal('aboutModal')" class="p-2 rounded-full text-slate-400 hover:text-white hover:bg-white/10">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                </button>
            </div>
            <div class="space-y-4 text-slate-300 text-sm leading-relaxed font-light">
                <p class="text-base text-white font-medium">A "Falcha" (फल्चा) in traditional Newar architecture is an open public pavilion where travelers rest, community elders converse, and generations have shared folk tales under carved wooden eaves.</p>
                <p>Falcha Filmation Studio was founded on this very philosophy: an open creative haven where authentic stories from the heart of Nepal meet contemporary cinematic craft.</p>
            </div>
        </div>
    </div>

    <!-- Contact Modal -->
    <div id="contactModal" class="fixed inset-0 z-40 hidden items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md">
        <div class="relative w-full max-w-3xl max-h-[90vh] bg-[#0c1017] border border-white/20 rounded-2xl shadow-[0_20px_60px_rgba(0,0,0,0.9)] overflow-y-auto flex flex-col p-6 sm:p-8" onclick="event.stopPropagation()">
            <div class="flex items-center justify-between pb-4 mb-6 border-b border-white/10">
                <div>
                    <h2 class="font-cinzel text-xl sm:text-2xl font-bold tracking-widest text-white uppercase">CONTACT</h2>
                    <p class="text-xs text-slate-400 font-montserrat tracking-widest uppercase mt-1">INQUIRE & BOOK PRODUCTIONS</p>
                </div>
                <button onclick="closeModal('contactModal')" class="p-2 rounded-full text-slate-400 hover:text-white hover:bg-white/10">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                </button>
            </div>
            <form action="contact_handler.php" method="POST" class="space-y-4">
                <div>
                    <label class="block text-xs font-montserrat uppercase tracking-wider text-slate-300 mb-1">Your Name / Studio</label>
                    <input type="text" name="name" required class="w-full px-3.5 py-2.5 rounded-lg bg-black/50 border border-white/15 text-white text-xs focus:outline-none focus:border-white/50">
                </div>
                <div>
                    <label class="block text-xs font-montserrat uppercase tracking-wider text-slate-300 mb-1">Email</label>
                    <input type="email" name="email" required class="w-full px-3.5 py-2.5 rounded-lg bg-black/50 border border-white/15 text-white text-xs focus:outline-none focus:border-white/50">
                </div>
                <div>
                    <label class="block text-xs font-montserrat uppercase tracking-wider text-slate-300 mb-1">Project Brief</label>
                    <textarea name="message" rows="3" required class="w-full px-3.5 py-2.5 rounded-lg bg-black/50 border border-white/15 text-white text-xs focus:outline-none focus:border-white/50"></textarea>
                </div>
                <button type="submit" class="w-full py-2.5 rounded-lg bg-white text-black font-semibold text-xs tracking-wider uppercase hover:bg-slate-200 transition-colors">
                    Send Proposal
                </button>
            </form>
        </div>
    </div>

    <!-- Scripts -->
    <script>
        function openModal(id) {
            const el = document.getElementById(id);
            if (el) {
                el.classList.remove('hidden');
                el.classList.add('flex');
            }
        }
        function closeModal(id) {
            const el = document.getElementById(id);
            if (el) {
                el.classList.add('hidden');
                el.classList.remove('flex');
            }
        }
        function playVideo(title, nepaliTitle, videoUrl, synopsis) {
            document.getElementById('modalVideoTitle').textContent = title;
            document.getElementById('modalVideoNepaliTitle').textContent = nepaliTitle || '';
            document.getElementById('modalVideoSynopsis').textContent = synopsis || '';
            const player = document.getElementById('mainVideoPlayer');
            player.src = videoUrl;
            openModal('videoModal');
            player.play().catch(e => console.log(e));
        }
        function closeVideoModal() {
            const player = document.getElementById('mainVideoPlayer');
            player.pause();
            player.src = '';
            closeModal('videoModal');
        }
        function selectCategory(categoryKey) {
            const cat = categoriesData[categoryKey];
            if (!cat) return;
            const heroThumb = document.getElementById('heroPosterImage');
            const heroTitle = document.getElementById('heroFilmTitle');
            const heroPlay = document.getElementById('heroPlayAction');
            if (heroThumb && cat.featured) {
                heroThumb.src = cat.featured.thumbnail;
                heroTitle.textContent = cat.featured.title;
                heroPlay.onclick = () => playVideo(cat.featured.title, cat.featured.nepaliTitle, cat.featured.videoUrl, cat.featured.synopsis);
            }
            // Update active styles
            document.querySelectorAll('.cat-card').forEach(c => c.classList.remove('scale-105'));
            const target = document.getElementById('card-' + categoryKey);
            if (target) target.classList.add('scale-105');
        }
        window.onclick = function(event) {
            ['videoModal', 'servicesModal', 'aboutModal', 'contactModal'].forEach(id => {
                const modal = document.getElementById(id);
                if (event.target === modal) {
                    if (id === 'videoModal') closeVideoModal();
                    else closeModal(id);
                }
            });
        };
    </script>
</body>
</html>

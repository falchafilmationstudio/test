<?php
/**
 * Falcha Filmation Studio - Data & Configuration File
 */

define('STUDIO_NAME', 'FALCHA');
define('STUDIO_SUBTITLE', 'FILMATION STUDIO');
define('STUDIO_TAGLINE', 'STORYTELLING IN MOTION');
define('STUDIO_LOCATION', 'Patan Durbar Heritage Zone, Lalitpur, Kathmandu Valley, Nepal');
define('STUDIO_EMAIL', 'contact@falchafilms.com');
define('STUDIO_PHONE', '+977 1 552 4890');

$mainShowreel = [
    'id' => 'falcha-main-showreel',
    'category' => 'Documentary Showreel',
    'title' => 'The Stone Whispers: Heritage of the Kathmandu Valley',
    'nepaliTitle' => 'ढुङ्गाका स्वरहरू : उपत्यकाको सम्पदा',
    'year' => '2026',
    'duration' => '03:45',
    'thumbnail' => 'assets/images/hero_pagoda.jpg',
    'videoUrl' => 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4',
    'synopsis' => 'An evocative cinematic celebration of Nepal’s architectural sanctuary, ancient courtyards, and communal Falchas where human tales have been woven for centuries.',
    'director' => 'John Rai Thakuri',
    'awards' => ['Best Cinematography - Himalayan Film Festival', 'Official Selection - Mountain Echoes'],
    'tags' => ['Showreel', 'Cinematography', 'Cultural Heritage', '4K Drone & 35mm']
];

$categories = [
    'documentaries' => [
        'id' => 'documentaries',
        'title' => 'DOCUMENTARIES',
        'devanagari' => 'डकुमेन्टारिज',
        'borderHex' => '#5cb8b2',
        'glowHex' => 'rgba(92, 184, 178, 0.35)',
        'thumbnail' => 'assets/images/documentaries.jpg',
        'featured' => [
            'title' => 'Voices of the Hearth',
            'nepaliTitle' => 'चुल्हाका सुस्केराहरू',
            'duration' => '28:12',
            'year' => '2025',
            'director' => 'Falcha Documentary Unit',
            'thumbnail' => 'assets/images/documentaries.jpg',
            'videoUrl' => 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
            'synopsis' => 'A poignant portrait of Aama and her generation preserving indigenous textile weaving and songs across the changing valleys of the Himalayas.',
            'awards' => ['Audience Choice - KIMFF 2025']
        ]
    ],
    'commercials' => [
        'id' => 'commercials',
        'title' => 'COMMERCIALS',
        'devanagari' => 'कमर्सियल्स',
        'borderHex' => '#ffffff',
        'glowHex' => 'rgba(255, 255, 255, 0.3)',
        'thumbnail' => 'assets/images/commercials.jpg',
        'featured' => [
            'title' => 'Himalayan Nectar: Pure Reserve',
            'nepaliTitle' => 'हिमालयन नेक्टर : मौलिक स्वाद',
            'duration' => '01:00',
            'year' => '2026',
            'director' => 'Commercial Studio Dept.',
            'thumbnail' => 'assets/images/commercials.jpg',
            'videoUrl' => 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
            'synopsis' => 'Tactile macro cinematography, fluid physics, and dramatic studio chiaroscuro highlighting pure botanical ingredients and artisanal glasswork.',
            'awards' => ['Best Commercial Campaign - Brand Nepal Gala 2025']
        ]
    ],
    'short_films' => [
        'id' => 'short_films',
        'title' => 'SHORT FILMS',
        'devanagari' => 'सर्ट फिल्म्स',
        'borderHex' => '#e07a68',
        'glowHex' => 'rgba(224, 122, 104, 0.35)',
        'thumbnail' => 'assets/images/short_films.jpg',
        'featured' => [
            'title' => 'The Evening Light',
            'nepaliTitle' => 'साँझको किरण',
            'duration' => '16:40',
            'year' => '2025',
            'director' => 'Falcha Narrative Team',
            'thumbnail' => 'assets/images/short_films.jpg',
            'videoUrl' => 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
            'synopsis' => 'Two childhood friends reunite in a warm Kathmandu apartment after seven years apart, unraveling promises spoken in their youth.',
            'awards' => ['Best Narrative Short - Nepal Cine Guild']
        ]
    ]
];

$services = [
    [
        'title' => 'Cinematic Direction & Production',
        'nepali' => 'चलचित्र निर्देशन तथा निर्माण',
        'desc' => 'Complete end-to-end film production from script development, location scouting in the Himalayas, casting, and multi-camera 4K/6K cinema pipeline.'
    ],
    [
        'title' => 'Documentary Research & Field Crews',
        'nepali' => 'वृत्तचित्र अनुसन्धान र फिल्ड टिम',
        'desc' => 'Deep ethnographical research, ethical community engagement, high-altitude expedition filming, and sensitive interview direction.'
    ],
    [
        'title' => 'Commercials & Brand Storytelling',
        'nepali' => 'व्यापारिक विज्ञापन र ब्रान्डिङ',
        'desc' => 'High-concept television commercials, social-first films, product tabletop cinematography, and brand launch films.'
    ],
    [
        'title' => 'Post-Production, Color & Sound',
        'nepali' => 'रङ्ग संयोजन र साउन्ड डिजाइन',
        'desc' => 'DaVinci Resolve HDR color grading, original orchestral & indigenous musical scoring, Dolby Atmos 7.1 sound mixing.'
    ]
];

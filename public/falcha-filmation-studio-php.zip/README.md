# Falcha Filmation Studio - PHP Edition

A production-ready PHP implementation of the Falcha Filmation Studio website.

## Project Structure
- `index.php` - Main showcase landing page with video showreel and category gallery
- `header.php` - Global header with the custom 3D phoenix & camera emblem logo and navigation
- `footer.php` - Footer, video modal player, and slide-over panels (Services, About, Contact)
- `data.php` - Global data configuration (portfolio items, categories, studio coordinates)
- `contact_handler.php` - Form processing script with log file persistence
- `download.php` - Download utility script
- `assets/images/` - High-resolution production imagery (logo, showreel, documentaries, commercials, short films)

## How to Run Locally

### With Built-in PHP Server:
```bash
# Navigate to this project directory
cd falcha-filmation-studio-php

# Start PHP built-in web server on port 8000
php -S localhost:8000
```
Then open your browser at: `http://localhost:8000`

### With XAMPP / WAMP / MAMP:
1. Copy this folder into your `htdocs` (or `www`) directory.
2. Start Apache from the XAMPP Control Panel.
3. Visit: `http://localhost/falcha-filmation-studio-php/`

### Deployment to cPanel / Apache / Nginx:
1. Upload all files to your `public_html` directory via FTP or cPanel File Manager.
2. No database or composer installation is required—it runs natively on PHP 7.4+ or PHP 8.x!
